<?php
session_start();
$error = "";

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $username = isset($_POST['username']) ? trim($_POST['username']) : "";
    $password = isset($_POST['password']) ? trim($_POST['password']) : "";
    $is_valid = false;
    $users = [];

    // 1. File-based authentication (users.php)
    if(file_exists('users.php')){
        if(function_exists('opcache_invalidate')){
            @opcache_invalidate('users.php', true);
        }
        $users = include 'users.php';
        if(is_array($users) && isset($users[$username])){
            if(password_verify($password, $users[$username]) || $password === $users[$username]){
                $is_valid = true;
            }
        }
    }

    // 2. Hardcoded admin login
    if(!$is_valid && $username == "admin" && $password == "1234"){
        $is_valid = true;
    }

    // 3. MySQL Database authentication (car_rental)
    if(!$is_valid){
        try {
            ini_set('default_socket_timeout', 1);
            $conn = mysqli_init();
            if($conn){
                $conn->options(MYSQLI_OPT_CONNECT_TIMEOUT, 1);
                if(@$conn->real_connect("127.0.0.1", "root", "", "car_rental") || @$conn->real_connect("localhost", "root", "", "car_rental")){
                    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
                    if($stmt){
                        $stmt->bind_param("s", $username);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        if($result && $result->num_rows > 0){
                            $row = $result->fetch_assoc();
                            if(password_verify($password, $row['password']) || $password === $row['password']){
                                $is_valid = true;
                            }
                        }
                        $stmt->close();
                    }
                    $conn->close();
                }
            }
        } catch (Throwable $e) {
            // DB connection fallback
        }
    }

    if($is_valid){
        $_SESSION['user'] = $username;
        header("Location: c_rental.php");
        exit();
    } else {
        $error = "Invalid Username or Password";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Car Rental</title>
    <style>
        body {
            text-align: center;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding-top: 100px;
            margin: 0;
        }
        .login-box {
            background: white;
            padding: 30px 40px;
            display: inline-block;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            width: 320px;
            box-sizing: border-box;
        }
        .login-box h2 {
            margin-top: 0;
            margin-bottom: 20px;
            color: #333;
            font-size: 26px;
        }
        .input-group {
            position: relative;
            margin: 10px 0;
        }
        input {
            padding: 10px 12px;
            width: 100%;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
        }
        input:focus {
            outline: none;
            border-color: #27ae60;
            box-shadow: 0 0 4px rgba(39, 174, 96, 0.4);
        }
        .toggle-password {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #777;
            user-select: none;
            display: flex;
            align-items: center;
        }
        .toggle-password svg {
            width: 18px;
            height: 18px;
        }
        button {
            padding: 10px 20px;
            width: 100%;
            background: #27ae60;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            margin-top: 10px;
            transition: background 0.3s;
        }
        button:hover {
            background: #219150;
        }
        .error-msg {
            color: #e74c3c;
            margin: 10px 0;
            font-size: 14px;
            font-weight: 500;
        }
        p {
            margin-top: 15px;
            font-size: 14px;
            color: #555;
        }
        a {
            color: #27ae60;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
        .back-home {
            display: block;
            margin-top: 12px;
            font-size: 13px;
            color: #7f8c8d;
        }
    </style>
</head>
<body>
<div class="login-box">
    <h2>Login</h2>
    <?php if(!empty($error)): ?>
        <p class="error-msg"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>
    <form method="POST" action="login.php">
        <div class="input-group">
            <input type="text" name="username" placeholder="Username" required autofocus>
        </div>
        <div class="input-group">
            <input type="password" id="password" name="password" placeholder="Password" required>
            <span class="toggle-password" onclick="togglePasswordVisibility('password', this)" title="Show/Hide Password">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                    <circle cx="12" cy="12" r="3"></circle>
                </svg>
            </span>
        </div>
        <button type="submit">Login</button>
    </form>
    <p>Don't have an account? <a href="register.php">Register here</a></p>
    <a href="index.html" class="back-home">← Back to Home</a>
</div>

<script>
function togglePasswordVisibility(fieldId, iconElem) {
    var field = document.getElementById(fieldId);
    if (field.type === "password") {
        field.type = "text";
        iconElem.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>`;
    } else {
        field.type = "password";
        iconElem.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>`;
    }
}
</script>
</body>
</html>