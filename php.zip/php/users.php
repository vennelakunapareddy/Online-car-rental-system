<?php
// File-based user storage
return array (
  'admin' => '$2y$12$aaJQ0p36ZfDD545Y20Mq8e4mfr9VwymGBayW3iOTsM48CLKEWf9r6',
  'srihitha' => '$2y$12$aaJQ0p36ZfDD545Y20Mq8e4mfr9VwymGBayW3iOTsM48CLKEWf9r6',
  'p.srihitha' => '$2y$12$aaJQ0p36ZfDD545Y20Mq8e4mfr9VwymGBayW3iOTsM48CLKEWf9r6',
  'Srihitha' => '$2y$12$5FXoiPXR5LpieypCtSUg/OSr/P.5vOR749B15ENNEIsIJ1zR1JarW',
);
