<?php
session_start();

// Handle Logout if requested via query param
if(isset($_GET['action']) && $_GET['action'] === 'logout'){
    $_SESSION = [];
    session_destroy();
    header("Location: login.php");
    exit();
}

// Redundant login authentication logic (as specified in PDF Page 3 & 11)
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login_username'])){
    $username = trim($_POST['login_username']);
    $password = trim($_POST['login_password']);
    $is_valid = false;
    
    if(file_exists('users.php')){
        if(function_exists('opcache_invalidate')){
            @opcache_invalidate('users.php', true);
        }
        $users = include 'users.php';
        if(is_array($users) && isset($users[$username]) && password_verify($password, $users[$username])){
            $is_valid = true;
        }
    }
    if(!$is_valid && $username == "admin" && $password == "1234"){
        $is_valid = true;
    }
    if($is_valid){
        $_SESSION['user'] = $username;
    }
}

// Ensure user is authenticated
if(!isset($_SESSION['user'])){
    header("Location: login.php");
    exit();
}

$current_user = $_SESSION['user'];

// Define available cars
$cars = [
    'toyota' => [
        'name' => 'Toyota Camry',
        'price' => 4000,
        'price_formatted' => '₹4000/day',
        'image' => 'toyota.jpg',
        'desc' => 'Great value! Reliable transport at ₹4,000/day'
    ],
    'bmw' => [
        'name' => 'BMW 5 Series',
        'price' => 12000,
        'price_formatted' => '₹12,000/day',
        'image' => 'bmw.jpg',
        'desc' => 'Premium executive luxury at ₹12,000/day'
    ],
    'porsche' => [
        'name' => 'Porsche 911',
        'price' => 25000,
        'price_formatted' => '₹25,000/day',
        'image' => 'porsche.jpg',
        'desc' => 'High performance sports experience at ₹25,000/day'
    ]
];

// Determine selected car (from GET param or default to bmw)
$selected_car_key = isset($_GET['car']) && isset($cars[$_GET['car']]) ? $_GET['car'] : 'bmw';
$selected_car = $cars[$selected_car_key];

// Default initial active tab
$active_tab = 'home';
if(isset($_GET['tab'])){
    $active_tab = htmlspecialchars($_GET['tab']);
} elseif(isset($_GET['car'])){
    $active_tab = 'booking';
}

$booking_confirmed = false;
$booking_details = null;
$success_message = "";

// Check if there is an existing booking in session
if(isset($_SESSION['last_booking'])){
    $booking_details = $_SESSION['last_booking'];
    $booking_confirmed = true;
    $success_message = "Success! " . htmlspecialchars($booking_details['passenger_name']) . ", your booking for " . htmlspecialchars($booking_details['car_name']) . " for " . htmlspecialchars($booking_details['days']) . " days is ₹" . htmlspecialchars($booking_details['total']) . ".";
}

// Handle Booking Submission
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_booking'])){
    $passenger_name = isset($_POST['passenger_name']) ? trim($_POST['passenger_name']) : $current_user;
    $days = isset($_POST['days']) ? intval($_POST['days']) : 1;
    $car_key = isset($_POST['car_key']) && isset($cars[$_POST['car_key']]) ? $_POST['car_key'] : $selected_car_key;
    
    if($days < 1) $days = 1;
    
    $booked_car = $cars[$car_key];
    $total_cost = $days * $booked_car['price'];

    $booking_details = [
        'passenger_name' => !empty($passenger_name) ? $passenger_name : $current_user,
        'car_name' => $booked_car['name'],
        'car_key' => $car_key,
        'days' => $days,
        'price' => $booked_car['price'],
        'total' => $total_cost
    ];

    $_SESSION['last_booking'] = $booking_details;
    $booking_confirmed = true;
    $active_tab = 'booking';
    $selected_car_key = $car_key;
    $selected_car = $booked_car;

    $success_message = "Success! " . htmlspecialchars($booking_details['passenger_name']) . ", your booking for " . htmlspecialchars($booking_details['car_name']) . " for " . htmlspecialchars($booking_details['days']) . " days is ₹" . htmlspecialchars($booking_details['total']) . ".";

    // Optional: save to MySQL if database is connected
    try {
        $conn = @new mysqli("localhost", "root", "", "car_rental");
        if(!$conn->connect_error){
            $conn->query("CREATE TABLE IF NOT EXISTS bookings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user VARCHAR(50) NOT NULL,
                passenger_name VARCHAR(100) NOT NULL,
                car_name VARCHAR(100) NOT NULL,
                days INT NOT NULL,
                price_per_day INT NOT NULL,
                total_cost INT NOT NULL,
                booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");

            $stmt = $conn->prepare("INSERT INTO bookings (user, passenger_name, car_name, days, price_per_day, total_cost) VALUES (?, ?, ?, ?, ?, ?)");
            if($stmt){
                $stmt->bind_param("sssiii", $current_user, $booking_details['passenger_name'], $booking_details['car_name'], $days, $booked_car['price'], $total_cost);
                $stmt->execute();
                $stmt->close();
            }
            $conn->close();
        }
    } catch (Throwable $e) {
        // Fallback gracefully
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Rental System - Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<header>
    <h1>Car Rental System</h1>
    <div class="user-status">
        Logged in as: <strong><?php echo htmlspecialchars($current_user); ?></strong> | <a href="logout.php">Logout</a>
    </div>
</header>

<nav>
    <a id="nav-home" class="<?php echo $active_tab === 'home' ? 'active-nav' : ''; ?>" onclick="showSection('home')">Home</a>
    <a id="nav-cars" class="<?php echo $active_tab === 'cars' ? 'active-nav' : ''; ?>" onclick="showSection('cars')">Cars</a>
    <a id="nav-booking" class="<?php echo $active_tab === 'booking' ? 'active-nav' : ''; ?>" onclick="showSection('booking')">Booking</a>
    <a id="nav-contact" class="<?php echo $active_tab === 'contact' ? 'active-nav' : ''; ?>" onclick="showSection('contact')">Contact</a>
</nav>

<!-- ================= HOME SECTION ================= -->
<div id="home" class="section <?php echo $active_tab === 'home' ? 'active' : ''; ?>">
    <h2>Welcome to your Dashboard</h2>

    <?php if(!empty($success_message)): ?>
        <div class="success-banner">
            <?php echo $success_message; ?>
        </div>
    <?php endif; ?>

    <p class="sub-text">Premium vehicles available for your next journey.</p>
    
    <div class="banner-container">
        <img src="car.jpeg" alt="Car Fleet" class="banner-img">
    </div>
</div>

<!-- ================= CARS SECTION ================= -->
<div id="cars" class="section <?php echo $active_tab === 'cars' ? 'active' : ''; ?>">
    <h2>Available Cars</h2>
    <div>
        <button type="button" class="btn-orange" onclick="findPerfectCar()">Find Your Perfect Car</button>
    </div>

    <div class="cars-container">
        <!-- Toyota Camry -->
        <div class="card">
            <img src="toyota.jpg" alt="Toyota Camry">
            <h3>Toyota Camry</h3>
            <p class="price">₹4000/day</p>
            <button type="button" onclick="selectCar('toyota')">Book Now</button>
        </div>

        <!-- BMW 5 Series -->
        <div class="card">
            <img src="bmw.jpg" alt="BMW 5 Series">
            <h3>BMW 5 Series</h3>
            <p class="price">₹12,000/day</p>
            <button type="button" onclick="selectCar('bmw')">Book Now</button>
        </div>

        <!-- Porsche 911 -->
        <div class="card">
            <img src="porsche.jpg" alt="Porsche 911">
            <h3>Porsche 911</h3>
            <p class="price">₹25,000/day</p>
            <button type="button" onclick="selectCar('porsche')">Book Now</button>
        </div>
    </div>
</div>

<!-- ================= BOOKING SECTION ================= -->
<div id="booking" class="section <?php echo $active_tab === 'booking' ? 'active' : ''; ?>">
    <h2>Book Now</h2>

    <div class="selected-car-box" id="car-selection-display">
        Car Selected: <span id="display-car-name"><?php echo htmlspecialchars($selected_car['name']); ?></span> (₹<span id="display-car-price"><?php echo htmlspecialchars($selected_car['price']); ?></span>/day)
    </div>

    <form method="POST" action="c_rental.php" class="booking-form" onsubmit="return validateAndConfirmBooking();">
        <input type="hidden" name="confirm_booking" value="1">
        <input type="hidden" id="car_key_input" name="car_key" value="<?php echo htmlspecialchars($selected_car_key); ?>">

        <input type="text" name="passenger_name" id="passenger_name" placeholder="Enter Name" value="<?php echo isset($booking_details['passenger_name']) ? htmlspecialchars($booking_details['passenger_name']) : htmlspecialchars($current_user); ?>" required>

        <input type="number" name="days" id="booking_days" placeholder="Number of Days" min="1" value="<?php echo isset($booking_details['days']) ? htmlspecialchars($booking_details['days']) : '2'; ?>" required>

        <button type="submit">Confirm Booking</button>
    </form>

    <?php if($booking_confirmed && $booking_details): ?>
    <div class="confirmation-section">
        <h2>Booking Confirmation</h2>
        <table class="confirmation-table">
            <thead>
                <tr>
                    <th>Details</th>
                    <th>Information</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Passenger Name</td>
                    <td><?php echo htmlspecialchars($booking_details['passenger_name']); ?></td>
                </tr>
                <tr>
                    <td>Selected Car</td>
                    <td><?php echo htmlspecialchars($booking_details['car_name']); ?></td>
                </tr>
                <tr>
                    <td>Number of Days</td>
                    <td><?php echo htmlspecialchars($booking_details['days']); ?></td>
                </tr>
                <tr>
                    <td>Price per Day</td>
                    <td>₹<?php echo htmlspecialchars($booking_details['price']); ?></td>
                </tr>
                <tr class="total-row">
                    <td>Total Cost</td>
                    <td>₹<?php echo htmlspecialchars($booking_details['total']); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<!-- ================= CONTACT SECTION ================= -->
<div id="contact" class="section <?php echo $active_tab === 'contact' ? 'active' : ''; ?>">
    <div class="contact-box">
        <h2>Contact Us</h2>
        <p>Email: support@carrental.com</p>
    </div>
</div>

<script>
// Car catalog dictionary
var carCatalog = {
    'toyota': {
        name: 'Toyota Camry',
        price: 4000,
        desc: 'Toyota Camry - Great value! Reliable transport at ₹4,000/day'
    },
    'bmw': {
        name: 'BMW 5 Series',
        price: 12000,
        desc: 'BMW 5 Series - Premium executive luxury at ₹12,000/day'
    },
    'porsche': {
        name: 'Porsche 911',
        price: 25000,
        desc: 'Porsche 911 - High performance sports experience at ₹25,000/day'
    }
};

// Switch between dashboard sections (Home, Cars, Booking, Contact)
function showSection(sectionId) {
    var sections = document.querySelectorAll('.section');
    sections.forEach(function(sec) {
        sec.classList.remove('active');
    });

    var navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(function(link) {
        link.classList.remove('active-nav');
    });

    var targetSection = document.getElementById(sectionId);
    if(targetSection) {
        targetSection.classList.add('active');
    }

    var targetNav = document.getElementById('nav-' + sectionId);
    if(targetNav) {
        targetNav.classList.add('active-nav');
    }

    // Update URL hash without reload
    window.location.hash = sectionId;
}

// "Find Your Perfect Car" interactive budget prompt
function findPerfectCar() {
    var budgetInput = prompt("What's your monthly budget in ₹? (e.g., 4000, 12000, 25000)");
    if(budgetInput === null || budgetInput.trim() === "") {
        return;
    }
    
    var budget = parseInt(budgetInput.replace(/[^0-9]/g, ''));
    if(isNaN(budget)) {
        alert("Please enter a valid numeric budget.");
        return;
    }

    if(budget <= 4000) {
        alert(carCatalog['toyota'].desc);
        selectCar('toyota');
    } else if(budget <= 12000) {
        alert(carCatalog['bmw'].desc);
        selectCar('bmw');
    } else {
        alert(carCatalog['porsche'].desc);
        selectCar('porsche');
    }
}

// Select a car and transition to Booking section
function selectCar(carKey) {
    if(!carCatalog[carKey]) return;

    var car = carCatalog[carKey];
    document.getElementById('car_key_input').value = carKey;
    document.getElementById('display-car-name').innerText = car.name;
    document.getElementById('display-car-price').innerText = car.price;

    showSection('booking');
}

// Validate and show confirmation dialog before submission
function validateAndConfirmBooking() {
    var name = document.getElementById('passenger_name').value.trim();
    var days = document.getElementById('booking_days').value.trim();

    if(!name) {
        alert("Please enter passenger name.");
        return false;
    }
    if(!days || parseInt(days) < 1) {
        alert("Please enter valid number of days.");
        return false;
    }

    // Exact confirmation prompt as shown in Page 21 Screenshot 2
    var isConfirmed = confirm("Confirm Booking?");
    return isConfirmed;
}

// Check URL query parameters or hash on load
window.addEventListener('DOMContentLoaded', function() {
    var urlParams = new URLSearchParams(window.location.search);
    var carParam = urlParams.get('car');
    if(carParam && carCatalog[carParam]) {
        selectCar(carParam);
    }
    
    // Check hash in URL
    if(window.location.hash) {
        var hash = window.location.hash.substring(1);
        if(['home', 'cars', 'booking', 'contact'].indexOf(hash) !== -1) {
            showSection(hash);
        }
    }
});
</script>

</body>
</html>