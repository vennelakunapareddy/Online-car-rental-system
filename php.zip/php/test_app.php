<?php
// Automated test script for Car Rental System
echo "========================================================\n";
echo "      Testing Online Car Rental System Components       \n";
echo "========================================================\n\n";

$pass_count = 0;
$fail_count = 0;

function assert_test($condition, $name) {
    global $pass_count, $fail_count;
    if ($condition) {
        echo "[PASS] $name\n";
        $pass_count++;
    } else {
        echo "[FAIL] $name\n";
        $fail_count++;
    }
}

// 1. Test index.html exists and contains key elements
$index_html = file_get_contents('index.html');
assert_test(strpos($index_html, 'Premium Car Rental') !== false, "index.html contains heading");
assert_test(strpos($index_html, 'Luxury Sedans') !== false, "index.html contains car categories");
assert_test(strpos($index_html, 'chooseCategory') !== false, "index.html contains chooseCategory JS");
assert_test(strpos($index_html, 'feedbackLoop') !== false, "index.html contains feedbackLoop JS");

// 2. Test users.php returns array with credentials
$users = include 'users.php';
assert_test(is_array($users), "users.php returns array");
assert_test(isset($users['srihitha']) && password_verify('1234', $users['srihitha']), "users.php contains valid srihitha hash");
assert_test(isset($users['admin']), "users.php contains admin hash");

// 3. Test styles.css exists and contains classes
$css = file_get_contents('styles.css');
assert_test(strpos($css, '.card') !== false, "styles.css contains .card class");
assert_test(strpos($css, '.section') !== false, "styles.css contains .section class");
assert_test(strpos($css, '.confirmation-table') !== false, "styles.css contains .confirmation-table class");

// 4. Test images exist
assert_test(file_exists('car.jpeg') && filesize('car.jpeg') > 1000, "car.jpeg exists and is valid");
assert_test(file_exists('toyota.jpg') && filesize('toyota.jpg') > 1000, "toyota.jpg exists");
assert_test(file_exists('bmw.jpg') && filesize('bmw.jpg') > 1000, "bmw.jpg exists");
assert_test(file_exists('porsche.jpg') && filesize('porsche.jpg') > 1000, "porsche.jpg exists");

// 5. Test booking calculation logic
$bmw_price = 12000;
$days = 2;
$total = $days * $bmw_price;
assert_test($total === 24000, "Booking calculation matches PDF screenshot (2 days * 12000 = 24000)");

echo "\n--------------------------------------------------------\n";
echo "Results: $pass_count Passed, $fail_count Failed\n";
echo "========================================================\n";

if ($fail_count > 0) {
    exit(1);
}
