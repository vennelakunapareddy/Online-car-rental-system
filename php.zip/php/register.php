<?php
session_start();
$error = "";
$success = "";

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $username = isset($_POST['username']) ? trim($_POST['username']) : "";
    $password = isset($_POST['password']) ? trim($_POST['password']) : "";
    $confirm_password = isset($_POST['confirm_password']) ? trim($_POST['confirm_password']) : "";
    $is_valid = false;

    if(empty($username) || empty($password)){
        $error = "Please enter username and password";
    } elseif(!empty($confirm_password) && $password !== $confirm_password){
        $error = "Passwords do not match";
    } else {
        $db_connected = false;

        // Try MySQL Database connection with fast timeout
        try {
            ini_set('default_socket_timeout', 1);
            $server_conn = mysqli_init();
            if($server_conn){
                $server_conn->options(MYSQLI_OPT_CONNECT_TIMEOUT, 1);
                if(@$server_conn->real_connect("127.0.0.1", "root", "") || @$server_conn->real_connect("localhost", "root", "")){
                    $server_conn->query("CREATE DATABASE IF NOT EXISTS car_rental");
                    $server_conn->close();
                }
            }

            $conn = mysqli_init();
            if($conn){
                $conn->options(MYSQLI_OPT_CONNECT_TIMEOUT, 1);
                if(@$conn->real_connect("127.0.0.1", "root", "", "car_rental") || @$conn->real_connect("localhost", "root", "", "car_rental")){
                    $db_connected = true;

                    // Ensure table exists
                    $conn->query("CREATE TABLE IF NOT EXISTS users (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        username VARCHAR(50) NOT NULL UNIQUE,
                        password VARCHAR(255) NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )");

                    // Check if user already exists
                    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
                    if($stmt){
                        $stmt->bind_param("s", $username);
                        $stmt->execute();
                        $stmt->store_result();
                        if($stmt->num_rows > 0){
                            $error = "Username already exists";
                            $stmt->close();
                        } else {
                            $stmt->close();
                            // Insert new user
                            $insert_stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
                            if($insert_stmt){
                                $hashed_pass = password_hash($password, PASSWORD_DEFAULT);
                                $insert_stmt->bind_param("ss", $username, $hashed_pass);
                                if($insert_stmt->execute()){
                                    $is_valid = true;
                                } else {
                                    $error = "Registration failed. Please try again.";
                                }
                                $insert_stmt->close();
                            }
                        }
                    }
                    $conn->close();
                }
            }
        } catch (Throwable $e) {
            $db_connected = false;
        }

        // Fallback login / file-based storage if database fails or is offline
        if(!$db_connected && empty($error)){
            // File-based registration in users.php
            $users = [];
            if(file_exists('users.php')){
                if(function_exists('opcache_invalidate')){
                    @opcache_invalidate('users.php', true);
                }
                $users = include 'users.php';
                if(!is_array($users)) $users = [];
            }
            
            $users[$username] = password_hash($password, PASSWORD_DEFAULT);
            $export_data = "<?php\n// File-based user storage\nreturn " . var_export($users, true) . ";\n";
            @file_put_contents('users.php', $export_data);
            if(function_exists('opcache_invalidate')){
                @opcache_invalidate('users.php', true);
            }

            // Allow fallback login
            $is_valid = true;
        }

        // Also sync to users.php file if DB registration succeeded
        if($is_valid && $db_connected){
            $users = [];
            if(file_exists('users.php')){
                if(function_exists('opcache_invalidate')){
                    @opcache_invalidate('users.php', true);
                }
                $users = include 'users.php';
                if(!is_array($users)) $users = [];
            }
            $users[$username] = password_hash($password, PASSWORD_DEFAULT);
            $export_data = "<?php\n// File-based user storage\nreturn " . var_export($users, true) . ";\n";
            @file_put_contents('users.php', $export_data);
            if(function_exists('opcache_invalidate')){
                @opcache_invalidate('users.php', true);
            }
        }

        // If registration successful, store session and redirect to dashboard
        if($is_valid){
            $_SESSION['user'] = $username;
            header("Location: c_rental.php");
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account - Car Rental</title>
    <style>
        body {
            text-align: center;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding-top: 80px;
            margin: 0;
        }
        .register-box {
            background: white;
            padding: 35px 40px;
            display: inline-block;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            width: 330px;
            box-sizing: border-box;
        }
        .register-box h2 {
            margin-top: 0;
            margin-bottom: 20px;
            color: #222;
            font-size: 24px;
            font-weight: bold;
        }
        .input-group {
            position: relative;
            margin: 10px 0;
        }
        input {
            padding: 11px 12px;
            width: 100%;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
        }
        input:focus {
            outline: none;
            border-color: #27ae60;
            box-shadow: 0 0 4px rgba(39, 174, 96, 0.4);
        }
        .toggle-password {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #777;
            user-select: none;
            display: flex;
            align-items: center;
        }
        .toggle-password svg {
            width: 18px;
            height: 18px;
        }
        button {
            padding: 11px 20px;
            width: 100%;
            background: #27ae60;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            margin-top: 15px;
            transition: background 0.3s;
        }
        button:hover {
            background: #219150;
        }
        .error-msg {
            color: #e74c3c;
            margin: 10px 0;
            font-size: 14px;
            font-weight: 500;
        }
        p {
            margin-top: 20px;
            font-size: 14px;
            color: #555;
        }
        a {
            color: #27ae60;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
        .back-home {
            display: block;
            margin-top: 12px;
            font-size: 13px;
            color: #7f8c8d;
        }
    </style>
</head>
<body>
<div class="register-box">
    <h2>Create Account</h2>
    <?php if(!empty($error)): ?>
        <p class="error-msg"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>
    <form method="POST" action="register.php">
        <div class="input-group">
            <input type="text" name="username" placeholder="Username" required autofocus value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
        </div>
        <div class="input-group">
            <input type="password" id="reg_password" name="password" placeholder="Password" required>
            <span class="toggle-password" onclick="togglePasswordVisibility('reg_password', this)" title="Show/Hide Password">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                    <circle cx="12" cy="12" r="3"></circle>
                </svg>
            </span>
        </div>
        <div class="input-group">
            <input type="password" id="reg_confirm_password" name="confirm_password" placeholder="Confirm Password" required>
            <span class="toggle-password" onclick="togglePasswordVisibility('reg_confirm_password', this)" title="Show/Hide Password">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                    <circle cx="12" cy="12" r="3"></circle>
                </svg>
            </span>
        </div>
        <button type="submit">Register</button>
    </form>
    <p>Already have an account? <a href="login.php">Login here</a></p>
    <a href="index.html" class="back-home">← Back to Home</a>
</div>

<script>
function togglePasswordVisibility(fieldId, iconElem) {
    var field = document.getElementById(fieldId);
    if (field.type === "password") {
        field.type = "text";
        iconElem.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>`;
    } else {
        field.type = "password";
        iconElem.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>`;
    }
}
</script>
</body>
</html>